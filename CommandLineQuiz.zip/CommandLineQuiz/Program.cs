﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.IO;

namespace quizEngine
{
    class Program
    {
        private static int score = 0;
        static void Main(string[] args)
        {    
            //create questions and answers            
            List<Question> questions = CreateQuestions();
            Console.ForegroundColor = ConsoleColor.White;
            Random rndnummer = new Random();
            
            
            Random r = new Random();
            
            int nummer = rndnummer.Next(2);     // Maakt een random nummer -   0-1
            if (nummer == 0) {
                questions.Reverse();
            } else if (nummer == 1) {
               
            }
            Random randomInt = new Random();
            int RandomNummber = rndnummer.Next(12);  //Random nummer tussen 0 - 11
            switch (RandomNummber) {
            case 0:
               questions.RemoveAt(0);questions.RemoveAt(0);
               break;
            case 1:
               questions.RemoveAt(1);questions.RemoveAt(3);
               break;
            case 2:
               questions.RemoveAt(2);questions.RemoveAt(5);
               break;
            case 3:
               questions.RemoveAt(3);questions.RemoveAt(8);
               break;
            case 4:
               questions.RemoveAt(4);questions.RemoveAt(5);
               break;
            case 5:
               questions.RemoveAt(5);questions.RemoveAt(3);
               break;
            case 6:
               questions.RemoveAt(6);questions.RemoveAt(9);
               break;
            case 7:
               questions.RemoveAt(7);questions.RemoveAt(10);
               break;
            case 8:
               questions.RemoveAt(8);questions.RemoveAt(5);
               break;
            case 9:
               questions.RemoveAt(9);questions.RemoveAt(4);
               break;
            case 10:
               questions.RemoveAt(10);questions.RemoveAt(8);
               break;
            case 11:
               questions.RemoveAt(11);questions.RemoveAt(1);
               break;
            case 12:
               questions.RemoveAt(1);questions.RemoveAt(2);
               break;
            case 13:
               questions.RemoveAt(2);questions.RemoveAt(3);
               break;
            case 14:
               questions.RemoveAt(3);questions.RemoveAt(4);
               break;
            case 15:
               questions.RemoveAt(4);questions.RemoveAt(5);
               break;
            case 16:
               questions.RemoveAt(5);questions.RemoveAt(6);
               break;
            case 17:
               questions.RemoveAt(6);questions.RemoveAt(7);
               break;
            case 18:
               questions.RemoveAt(7);questions.RemoveAt(8);
               break;
            case 19:
               questions.RemoveAt(8);questions.RemoveAt(9);
               break;
            case 20:
               questions.RemoveAt(9);questions.RemoveAt(10);
               break;
            case 21:
               questions.RemoveAt(10);questions.RemoveAt(8);
               break;
            case 22:
               questions.RemoveAt(11);questions.RemoveAt(1);
               break;
}
            //Gaat door elke vraag.
            int i = 0;
            foreach(Question q in questions){
                                i++;
                Random rnd = new Random();
                Console.Clear();

                string JouwScore = "Score : "+score;
                string VraagVanDe = "Vraag "+i+" Van de "+questions.Count;
                string DeVraag = "Vraag "+i+": "+ q.GetString();
                Console.WriteLine();Console.WriteLine();Console.WriteLine();
                Console.WriteLine(String.Format("{0," + ((Console.WindowWidth / 2) + (JouwScore.Length / 2)) + "}", JouwScore));
                Console.WriteLine(String.Format("{0," + ((Console.WindowWidth / 2) + (VraagVanDe.Length / 2)) + "}", VraagVanDe));
                Console.WriteLine();
                Console.WriteLine(String.Format("{0," + ((Console.WindowWidth / 2) + (DeVraag.Length / 2)) + "}", DeVraag));
                Console.WriteLine();
              
                int j = 0;
                foreach(Answer a in q.GetOptions()){
                    j++;
                    string Optie = "Type  "+ j + " for : "+a.GetString();
                    Console.WriteLine(String.Format("{0," + ((Console.WindowWidth / 2) + (Optie.Length / 2)) + "}", Optie));
                    Console.WriteLine();                
}
                
                //Wacht op de imput van de speler en kijkt of het een Integer is
                int input;
                bool parsed = false;
                do{
                    string EnterWith = "Please answer with a number";
                    Console.WriteLine(String.Format("{0," + ((Console.WindowWidth / 2) + (EnterWith.Length / 2)) + "}", EnterWith));
                    parsed = int.TryParse(Console.ReadLine(), out input);
                }
                while(!parsed);
                 
                int result = q.AnswerIt(input-1);//checked of het anwoord goed is -1 is fout
                if(result > -1){//RIGHT
                    score += result;
                    Console.Clear();
                    Console.BackgroundColor = ConsoleColor.Green;
                    Console.WriteLine("Het antwoord goed!");
                    Console.WriteLine("+" +result);
                    Console.Beep(1000, 100);
                    Thread.Sleep(1500);
                    Console.Clear();
                    Console.BackgroundColor = ConsoleColor.Black;
                }else{//WRONG
                    Console.Clear();
                    Console.BackgroundColor = ConsoleColor.Red;     
                    Console.WriteLine("Het antwoord is fout, !");
                    Console.Beep(2766, 1000);
                    Thread.Sleep(1500);
                    Console.Clear();
                    Console.BackgroundColor = ConsoleColor.Black;                       
                }                
            }
            //Nadat de vragen zijn beantwoord kan je je naam invullen - 
            //Wanneer je geen naam op geeft zegt hij dat er niks is opgegeven wacht hij 2 seconden en gaat weer door
            //En maakt hij geen nieuwe score aan
            Console.Clear();
            string GameOver = "De game is voorbij jou score is : "+ score + ", Dit heb je goed gedaan";
            string EnterName = "Wat is uw naam? als je geen naam noemt word je score niet opgeslagen";
            Console.WriteLine(String.Format("{0," + ((Console.WindowWidth / 2) + (GameOver.Length / 2)) + "}", GameOver));  
            Console.WriteLine(String.Format("{0," + ((Console.WindowWidth / 2) + (EnterName.Length / 2)) + "}", EnterName));
                    
            string playerName = Console.ReadLine();
            if(playerName == "") {
            Console.WriteLine("Geen naam opgegeven, Daarom heb ik dus ook geen score opgeslagen");
            System.Threading.Thread.Sleep(2000);
            }

            if (playerName != "") {
            HighScore.WriteHighScore(playerName,score,"highScore.txt");  
            }     

            //print highscore after highscore is saved
            string[] highScore = ListSorter.GetSortedHighScore("highScore.txt");
            
            Console.Clear();
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.White;
            string HighScoremsg = "+++++++++++++ Highscore +++++++++++++";
            Console.WriteLine(String.Format("{0," + ((Console.WindowWidth / 2) + (HighScoremsg.Length / 2)) + "}", HighScoremsg));
            Console.WriteLine();
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.White;
            int count = highScore.Length;
            if(count>10)count = 10;
            for(int k=0;k<count;k++){
                Console.WriteLine(String.Format("{0," + ((Console.WindowWidth / 2) + (highScore[k].Length / 2)) + "}", highScore[k]));
            }   
             //Maria song van internet hier beneden
            Console.Beep(659, 125); Console.Beep(659, 125); Thread.Sleep(125); Console.Beep(659, 125); Thread.Sleep(167); Console.Beep(523, 125); Console.Beep(659, 125); Thread.Sleep(125); Console.Beep(784, 125); Thread.Sleep(375); Console.Beep(392, 125); Thread.Sleep(375); Console.Beep(523, 125); Thread.Sleep(250); Console.Beep(392, 125); Thread.Sleep(250); Console.Beep(330, 125); Thread.Sleep(250); Console.Beep(440, 125); Thread.Sleep(125); Console.Beep(494, 125); Thread.Sleep(125); Console.Beep(466, 125); Thread.Sleep(42); Console.Beep(440, 125); Thread.Sleep(125); Console.Beep(392, 125); Thread.Sleep(125); Console.Beep(659, 125); Thread.Sleep(125); Console.Beep(784, 125); Thread.Sleep(125); Console.Beep(880, 125); Thread.Sleep(125); Console.Beep(698, 125); Console.Beep(784, 125); Thread.Sleep(125); Console.Beep(659, 125); Thread.Sleep(125); Console.Beep(523, 125); Thread.Sleep(125); Console.Beep(587, 125); Console.Beep(494, 125); Thread.Sleep(125); Console.Beep(523, 125); Thread.Sleep(250); Console.Beep(392, 125); Thread.Sleep(250); Console.Beep(330, 125); Thread.Sleep(250); Console.Beep(440, 125); Thread.Sleep(125); Console.Beep(494, 125); Thread.Sleep(125); Console.Beep(466, 125); Thread.Sleep(42); Console.Beep(440, 125); Thread.Sleep(125); Console.Beep(392, 125); Thread.Sleep(125); Console.Beep(659, 125); Thread.Sleep(125); Console.Beep(784, 125); Thread.Sleep(125); Console.Beep(880, 125); Thread.Sleep(125); Console.Beep(698, 125); Console.Beep(784, 125); Thread.Sleep(125); Console.Beep(659, 125); Thread.Sleep(125); Console.Beep(523, 125); Thread.Sleep(125); Console.Beep(587, 125); Console.Beep(494, 125); Thread.Sleep(375); Console.Beep(784, 125); Console.Beep(740, 125); Console.Beep(698, 125); Thread.Sleep(42); Console.Beep(622, 125); Thread.Sleep(125); Console.Beep(659, 125); Thread.Sleep(167); Console.Beep(415, 125); Console.Beep(440, 125); Console.Beep(523, 125); Thread.Sleep(125); Console.Beep(440, 125); Console.Beep(523, 125); Console.Beep(587, 125); Thread.Sleep(250); Console.Beep(784, 125); Console.Beep(740, 125); Console.Beep(698, 125); Thread.Sleep(42); Console.Beep(622, 125); Thread.Sleep(125); Console.Beep(659, 125); Thread.Sleep(167); Console.Beep(698, 125); Thread.Sleep(125); Console.Beep(698, 125); Console.Beep(698, 125); Thread.Sleep(625); Console.Beep(784, 125); Console.Beep(740, 125); Console.Beep(698, 125); Thread.Sleep(42); Console.Beep(622, 125); Thread.Sleep(125); Console.Beep(659, 125); Thread.Sleep(167); Console.Beep(415, 125); Console.Beep(440, 125); Console.Beep(523, 125); Thread.Sleep(125); Console.Beep(440, 125); Console.Beep(523, 125); Console.Beep(587, 125); Thread.Sleep(250); Console.Beep(622, 125); Thread.Sleep(250); Console.Beep(587, 125); Thread.Sleep(250); Console.Beep(523, 125); Thread.Sleep(1125); Console.Beep(784, 125); Console.Beep(740, 125); Console.Beep(698, 125); Thread.Sleep(42); Console.Beep(622, 125); Thread.Sleep(125); Console.Beep(659, 125); Thread.Sleep(167); Console.Beep(415, 125); Console.Beep(440, 125); Console.Beep(523, 125); Thread.Sleep(125); Console.Beep(440, 125); Console.Beep(523, 125); Console.Beep(587, 125); Thread.Sleep(250); Console.Beep(784, 125); Console.Beep(740, 125); Console.Beep(698, 125); Thread.Sleep(42); Console.Beep(622, 125); Thread.Sleep(125); Console.Beep(659, 125); Thread.Sleep(167); Console.Beep(698, 125); Thread.Sleep(125); Console.Beep(698, 125); Console.Beep(698, 125); Thread.Sleep(625); Console.Beep(784, 125); Console.Beep(740, 125); Console.Beep(698, 125); Thread.Sleep(42); Console.Beep(622, 125); Thread.Sleep(125); Console.Beep(659, 125); Thread.Sleep(167); Console.Beep(415, 125); Console.Beep(440, 125); Console.Beep(523, 125); Thread.Sleep(125); Console.Beep(440, 125); Console.Beep(523, 125); Console.Beep(587, 125); Thread.Sleep(250); Console.Beep(622, 125); Thread.Sleep(250); Console.Beep(587, 125); Thread.Sleep(250); Console.Beep(523, 125);
            
        }

        static List<Question> CreateQuestions(){
             return new List<Question>{
            
                new Question("In welk jaar was het live aid concert",
                50,
                new List<Answer>{
                    new Answer("- 1985"),
                    new Answer("- 1980"), 
                    new Answer("- 1983"),
                    new Answer("- 1998")
                    },
                0),
                new Question("wie zong 'I Know What Boys Like'?",
                50,
                new List<Answer>{
                    new Answer("- The Waitresses"),
                    new Answer("- Bow Wow Wow"), 
                    new Answer("- Bananarama")
                    },
                2),
                new Question("Van welke artist komt het nummer - Don’t Stop Believin’",
                50,
                new List<Answer>{
                    new Answer("- Creature of the night"),
                    new Answer("- journey"), 
                    new Answer("- I've been looking for freedom")
                    },
                1),
                new Question("Wie joinde micheal jackson op vocale met de song `Say Say Say`",
                50,
                new List<Answer>{
                    new Answer("- Bob George"),
                    new Answer("- Steve wonder"), 
                    new Answer("- Paul mcCartney"),
                    new Answer("- Elthon john")
                    },
                2),

                new Question("Wie zong 'Melt With You'?",
                50,
                new List<Answer>{
                    new Answer("- Modern English"),
                    new Answer("- Dead town"), 
                    new Answer("- Paul en ed"),
                    new Answer("- Rock And Rock")
                    },
                0), 

                new Question("In het lied Stray Cats werd gezegt, she's sexy and.. how old? wat moet bij de ... komen",
                50,
                new List<Answer>{
                    new Answer("- 15"),
                    new Answer("- 16"), 
                    new Answer("- 17"),
                    new Answer("- 18")
                    },
                2), 

                new Question("Wie zong het lied `Tainted love`",
                50,
                new List<Answer>{
                    new Answer("- NeverStop"),
                    new Answer("- Soft cell"), 
                    new Answer("- Love Rain"),
                    new Answer("- One route")
                    },
                1),


                new Question("Huey Lewis zegt, 'I want a new ____________'.",
                50,
                new List<Answer>{
                    new Answer("- drug"),
                    new Answer("- Love"), 
                    new Answer("- GirlFriend"),
                    new Answer("- House")
                    },
                0),

                new Question("In 'Time After Time', Waar leefde Cyndi Lauper en haar vriendje?",
                50,
                new List<Answer>{
                    new Answer("- Ze leefde niet"),
                    new Answer("- In een huis"), 
                    new Answer("- Op de straat"),
                    new Answer("- In een boomhut")
                    },
                3),

                new Question("Wat is de echte naam van Sting's? ",
                50,
                new List<Answer>{
                    new Answer("- Bob raves"),
                    new Answer("- Marcus horden"), 
                    new Answer("- Robbin finsh"),
                    new Answer("- Gorden summer")
                    },
                3),

                new Question("Wie zong het lied 'Rock Lobster'?",
                50,
                new List<Answer>{
                    new Answer("- The B23's"),
                    new Answer("- The B56's"), 
                    new Answer("- The B93's"),
                    new Answer("- The B52's")
                    },
                3),

                new Question("Price zong over een klein meisje in een _____ korvet",
                75,
                new List<Answer>{
                    new Answer("- rode"),
                    new Answer("- nieuwe"), 
                    new Answer("- oude"), 
                    new Answer("- grote")
                    },
                0)
            };

        }  


}

    }


